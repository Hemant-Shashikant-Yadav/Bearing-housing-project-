// Previous interfaces remain the same
export interface Configuration {
  id: string;
  userId: string;
  createdAt: string;
  bearing: Bearing;
  housing: Housing;
  parts: Part[];
}

export interface SavedConfig {
  configs: Configuration[];
}