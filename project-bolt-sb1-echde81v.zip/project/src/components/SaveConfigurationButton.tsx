import React from 'react';
import { Save } from 'lucide-react';
import { Bearing, Housing, Part, Configuration } from '../types';
import { getCurrentUser, saveConfiguration } from '../utils/localStorage';

interface SaveConfigurationButtonProps {
  bearing: Bearing;
  housing: Housing;
  parts: Part[];
  onSave: () => void;
}

export const SaveConfigurationButton: React.FC<SaveConfigurationButtonProps> = ({
  bearing,
  housing,
  parts,
  onSave
}) => {
  const handleSave = () => {
    const currentUser = getCurrentUser();
    if (!currentUser) return;

    const config: Configuration = {
      id: crypto.randomUUID(),
      userId: currentUser.id,
      createdAt: new Date().toISOString(),
      bearing,
      housing,
      parts
    };

    saveConfiguration(config);
    onSave();
  };

  return (
    <button
      onClick={handleSave}
      className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
    >
      <Save className="h-5 w-5 mr-2" />
      Save Configuration
    </button>
  );
};