import React from 'react';
import { Configuration } from '../types';
import { Trash2 } from 'lucide-react';

interface ConfigurationCardProps {
  config: Configuration;
  onDelete: (id: string) => void;
}

export const ConfigurationCard: React.FC<ConfigurationCardProps> = ({ config, onDelete }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-semibold">{config.bearing.name}</h3>
          <p className="text-sm text-gray-600">Created: {new Date(config.createdAt).toLocaleDateString()}</p>
        </div>
        <button
          onClick={() => onDelete(config.id)}
          className="text-red-500 hover:text-red-700"
        >
          <Trash2 className="h-5 w-5" />
        </button>
      </div>
      
      <div className="space-y-4">
        <div>
          <h4 className="font-medium">Housing</h4>
          <p className="text-sm text-gray-600">{config.housing.name}</p>
        </div>
        
        <div>
          <h4 className="font-medium">Selected Parts</h4>
          <ul className="text-sm text-gray-600">
            {config.parts.map(part => (
              <li key={part.id}>{part.name}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};