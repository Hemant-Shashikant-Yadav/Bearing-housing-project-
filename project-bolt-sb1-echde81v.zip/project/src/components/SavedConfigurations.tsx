import React, { useState, useEffect } from 'react';
import { Configuration } from '../types';
import { getUserConfigurations } from '../utils/localStorage';
import { ConfigurationCard } from './ConfigurationCard';

export const SavedConfigurations: React.FC = () => {
  const [configurations, setConfigurations] = useState<Configuration[]>([]);

  useEffect(() => {
    setConfigurations(getUserConfigurations());
  }, []);

  const handleDelete = (configId: string) => {
    const updatedConfigs = configurations.filter(config => config.id !== configId);
    localStorage.setItem('bearing_configurations', JSON.stringify(updatedConfigs));
    setConfigurations(updatedConfigs);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold mb-6">Saved Configurations</h2>
        {configurations.length === 0 ? (
          <p className="text-gray-600">No configurations saved yet.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {configurations.map(config => (
              <ConfigurationCard
                key={config.id}
                config={config}
                onDelete={handleDelete}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};