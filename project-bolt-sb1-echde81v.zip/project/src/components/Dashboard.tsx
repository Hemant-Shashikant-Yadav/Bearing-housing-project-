import React, { useState } from 'react';
import { Search, LogOut, Save, List } from 'lucide-react';
import { bearings, housings, parts } from '../data';
import { Bearing, Housing, Part } from '../types';
import { setCurrentUser } from '../utils/localStorage';
import { PartCard } from './PartCard';
import { SaveConfigurationButton } from './SaveConfigurationButton';
import { SavedConfigurations } from './SavedConfigurations';

interface DashboardProps {
  onLogout: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onLogout }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBearing, setSelectedBearing] = useState<Bearing | null>(null);
  const [selectedHousing, setSelectedHousing] = useState<Housing | null>(null);
  const [selectedParts, setSelectedParts] = useState<Part[]>([]);
  const [showAllBearings, setShowAllBearings] = useState(false);
  const [showConfigurations, setShowConfigurations] = useState(false);

  const handleLogout = () => {
    setCurrentUser(null);
    onLogout();
  };

  const handleSaveSuccess = () => {
    setSelectedBearing(null);
    setSelectedHousing(null);
    setSelectedParts([]);
    setShowConfigurations(true);
  };

  if (showConfigurations) {
    return (
      <div>
        <header className="bg-white shadow">
          <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
            <button
              onClick={() => setShowConfigurations(false)}
              className="text-blue-600 hover:text-blue-800"
            >
              ← Back to Configuration
            </button>
            <button
              onClick={handleLogout}
              className="flex items-center text-gray-600 hover:text-gray-900"
            >
              <LogOut className="h-5 w-5 mr-2" />
              Logout
            </button>
          </div>
        </header>
        <SavedConfigurations />
      </div>
    );
  }

  const filteredBearings = bearings.filter(bearing =>
    bearing.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    bearing.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const compatibleHousings = selectedBearing
    ? housings.filter(housing => housing.compatibleBearings.includes(selectedBearing.id))
    : [];

  const compatibleParts = selectedHousing
    ? parts.filter(part => part.compatibleHousings.includes(selectedHousing.id))
    : [];

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">Bearing Housing Configuration</h1>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowConfigurations(true)}
              className="flex items-center text-gray-600 hover:text-gray-900"
            >
              <List className="h-5 w-5 mr-2" />
              Saved Configurations
            </button>
            <button
              onClick={handleLogout}
              className="flex items-center text-gray-600 hover:text-gray-900"
            >
              <LogOut className="h-5 w-5 mr-2" />
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="mb-8">
            <div className="relative">
              <input
                type="text"
                placeholder="Search bearing by ID or name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-4 py-2 pl-10 border rounded-md"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
            <button
              onClick={() => setShowAllBearings(!showAllBearings)}
              className="mt-2 text-blue-600 hover:underline"
            >
              {showAllBearings ? 'Hide all bearings' : 'Show all bearings'}
            </button>
          </div>

          {(showAllBearings || searchQuery) && (
            <div className="mb-8">
              <h2 className="text-lg font-semibold mb-4">Available Bearings</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredBearings.map(bearing => (
                  <div
                    key={bearing.id}
                    onClick={() => setSelectedBearing(bearing)}
                    className={`p-4 border rounded-md cursor-pointer ${
                      selectedBearing?.id === bearing.id ? 'border-blue-500 bg-blue-50' : 'hover:border-gray-300'
                    }`}
                  >
                    <h3 className="font-medium">{bearing.name}</h3>
                    <p className="text-sm text-gray-600">ID: {bearing.id}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {selectedBearing && (
            <div className="space-y-8">
              <div>
                <h2 className="text-lg font-semibold mb-4">Compatible Housings</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {compatibleHousings.map(housing => (
                    <div
                      key={housing.id}
                      onClick={() => setSelectedHousing(housing)}
                      className={`p-4 border rounded-md cursor-pointer ${
                        selectedHousing?.id === housing.id ? 'border-blue-500 bg-blue-50' : 'hover:border-gray-300'
                      }`}
                    >
                      <h3 className="font-medium">{housing.name}</h3>
                      <p className="text-sm text-gray-600">{housing.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {selectedHousing && (
                <div>
                  <h2 className="text-lg font-semibold mb-4">Compatible Parts</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {compatibleParts.map(part => (
                      <PartCard
                        key={part.id}
                        part={part}
                        isSelected={selectedParts.some(p => p.id === part.id)}
                        onClick={() => {
                          if (selectedParts.find(p => p.id === part.id)) {
                            setSelectedParts(selectedParts.filter(p => p.id !== part.id));
                          } else {
                            setSelectedParts([...selectedParts, part]);
                          }
                        }}
                      />
                    ))}
                  </div>

                  {selectedParts.length > 0 && (
                    <div className="mt-8 flex justify-end">
                      <SaveConfigurationButton
                        bearing={selectedBearing}
                        housing={selectedHousing}
                        parts={selectedParts}
                        onSave={handleSaveSuccess}
                      />
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};