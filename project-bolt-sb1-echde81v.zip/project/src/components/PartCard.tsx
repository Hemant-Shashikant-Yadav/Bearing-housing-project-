import React from 'react';
import { Part } from '../types';

interface PartCardProps {
  part: Part;
  isSelected: boolean;
  onClick: () => void;
}

export const PartCard: React.FC<PartCardProps> = ({ part, isSelected, onClick }) => {
  return (
    <div
      onClick={onClick}
      className={`p-4 border rounded-md cursor-pointer transition-all ${
        isSelected ? 'border-blue-500 bg-blue-50' : 'hover:border-gray-300'
      }`}
    >
      <div className="aspect-w-16 aspect-h-9 mb-4">
        <img
          src={part.imageUrl}
          alt={part.name}
          className="object-cover rounded-md"
        />
      </div>
      <h3 className="font-medium">{part.name}</h3>
      <p className="text-sm text-gray-600">{part.description}</p>
      <span className="inline-block mt-2 text-xs px-2 py-1 bg-gray-100 rounded-full">
        {part.type}
      </span>
    </div>
  );
};